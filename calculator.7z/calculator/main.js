const screen = document.querySelector(".screen");

const btns = document.querySelectorAll(".btn");

const equalBtn = document.querySelector(".equals");
const clearBtn = document.querySelector(".clear");

screen.value="";

for (let i=0; i<btns.length; i++){
  btns[i].addEventListener("click", function(){
    
    /*The following if statement will ensure that if
    the screen is empty and you click an operator button (+, -, X or /)
    then an alert box will ask you to input a valid number because without numbers you cannot use operators
    It asks if the screen is empty && if the data-nums attribute of clicked button matches the operator symbols? if yes then show alert, else
    update screen.
    */

    if(((btns[i].getAttribute("data-nums")==="+")||(btns[i].getAttribute("data-nums")==="-")||(btns[i].getAttribute("data-nums")==="*")||(btns[i].getAttribute("data-nums")==="/")) && (screen.value==undefined||screen.value=="") ){
      alert("You must enter some number before you make any operation.");
    }
    else{
    screen.value += btns[i].getAttribute("data-nums");
    }
  })

}

equalBtn.addEventListener("click", function(){
  if(screen.value===""){alert("The input is empty, please enter a valid value.");
}
else{
  let result = eval(screen.value);
  screen.value = result;
}
})

clearBtn.addEventListener("click", function(){
  screen.value="";
})