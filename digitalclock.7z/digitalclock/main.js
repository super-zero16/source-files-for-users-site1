function setTime() {

  const clock = document.querySelector(".clock");
  

  let date = new Date();


  let hours = date.getHours(); //0-23
  let minutes = date.getMinutes(); //0-59
  let seconds = date.getSeconds(); //0-59

  let timeFormat = "AM";

  if(hours>=12){
    timeFormat = "PM";
  }

  if(hours>12){
    hours = hours-12;
  }

   function addZero(time){
    if (time<10) {
      time = "0"+time;
    }
    return time;
  }

  hours = addZero(hours);
  minutes = addZero(minutes);
  seconds = addZero(seconds);

 

  clock.innerHTML = `${hours} : ${minutes} :${seconds} ${timeFormat}`;


}

setTime(); //to display the first second immediately upon loading

setInterval(setTime, 1000) //fires the setTime function defined above every 1 second, setInterval is a pre-defined callback function and takes a function and an interval as arguments

