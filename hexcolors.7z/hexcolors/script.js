//array containing numbers in hexadecimal form
const hexNums = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"];

//select body, button and span which will display hex code
const docBody = document.querySelector("body");
const hexBtn = document.querySelector(".hexBtn");
const hexName = document.querySelector(".hex");

//generate random number between 0 and 15
function random() {
  return Math.floor(Math.random() * hexNums.length);
}

//event listener on color generator button
hexBtn.addEventListener("click", function () {
  let hexCol = "#";

  //loop that generates full hex code
  for (let i = 0; i < 6; i++) {
    hexCol += hexNums[random()];
  }
  //apply generated color to body and display hex code in span
  docBody.style.backgroundColor = hexCol;
  hexName.innerHTML = hexCol;
});
