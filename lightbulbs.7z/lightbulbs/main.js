const buttons = document.querySelectorAll("button");
const screen = document.querySelector(".screen");
const bulbs = document.querySelectorAll(".bulbImg");

for (let i = 0; i < buttons.length; i++) {
  let attr = buttons[i].getAttribute("data-btn");
  buttons[i].addEventListener("click", function () {
    function turnOnOff(data) {
      if (data === "offAll") {
        for (let i = 0; i < bulbs.length; i++) {
          bulbs[i].setAttribute("src", "bulboff.png");
        }
        screen.innerHTML = "All bulbs are off.";
      } else if (data === "onAll") {
        for (let i = 0; i < bulbs.length; i++) {
          bulbs[i].setAttribute("src", "bulbon.png");
        }
        screen.innerHTML = "All bulbs are on.";
      } else {
        for (let i = 0; i < bulbs.length; i++) {
          if (bulbs[i].getAttribute("data-bulb") == data) {
            if (bulbs[i].getAttribute("src") === "bulboff.png") {
              bulbs[i].setAttribute("src", "bulbon.png");
              screen.innerHTML = `bulb ${bulbs[i].getAttribute(
                "data-bulb"
              )} is on now.`;
              break;
            } else {
              bulbs[i].setAttribute("src", "bulboff.png");
              screen.innerHTML = `bulb ${bulbs[i].getAttribute(
                "data-bulb"
              )} is off now.`;
              break;
            }
          }
        }
      }
    }

    switch (attr) {
      case "1":
        turnOnOff("1");
        break;

      case "2":
        turnOnOff("2");
        break;

      case "3":
        turnOnOff("3");
        break;

      case "4":
        turnOnOff("4");
        break;

      case "offAll":
        if (screen.innerHTML === "All bulbs are off.") {
          alert("All bulbs are already off.");
        } else {
          turnOnOff("offAll");
        }
        break;

      case "onAll":
        if (screen.innerHTML === "All bulbs are on.") {
          alert("All bulbs are already on");
        } else {
          turnOnOff("onAll");
        }
        break;
    }
  });
}
