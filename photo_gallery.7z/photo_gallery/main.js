const displayedImage = document.querySelector(".displayed-img");
const thumbBar = document.querySelector(".thumb-bar");

/* Looping through images */
for (let i = 0; i < 5; i++) {
  let childImg = "images/" + "pic" + (i + 1) + ".jpg";
  let element = document.createElement("img");
  element.setAttribute("src", childImg);
  thumbBar.appendChild(element);
}

thumbBar.addEventListener("click", function (e) {
  if (e.target && e.target.nodeName == "IMG") {
    displayedImage.setAttribute("src", e.target.getAttribute("src"));
  }
});
