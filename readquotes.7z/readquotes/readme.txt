quotes.txt file is not necessary for doing this project.
It is there just in case user wants to collect a lot of quotes from various sources and store them in one place (eg. inside quotes.txt). 
User can then simply copy paste entire data from it to script.js file (if it doesn't already have a quotes array)