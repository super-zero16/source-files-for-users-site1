//below 27 quotes and their author name have been put in an array, in form of 27 objects whose first key is quote and second key is author

const quoteArray = [
  {
    quote:
      "Just as a mirror reflects as a mans face his personality is reflected in his choice of friends. One must always be careful in forming friendships and acquaintances, for one’s friends, are in a way, an extension of one’s inner inclinations and tendencies.",
    author: "Chanakya",
  },
  { quote: "No one can defeat a powerful mind.", author: "Chanakya" },
  {
    quote:
      "The biggest guru-mantra is: never share your secrets with anybody. It will destroy you.",
    author: "Chanakya",
  },
  {
    quote:
      "Even if a snake is not poisonous, it should pretend to be venomous.",
    author: "Chanakya",
  },
  {
    quote:
      "Before you start some work always ask yourselves three questions why I am doing it, what the results might be and will I be successful. Only when you think deeply and find satisfactory answers to these questions, go ahead.",
    author: "Chanakya",
  },
  {
    quote:
      "He who is overly attached to his family members, experiences fear and sorrow, for the root of all grief is attachment. Thus one should discard attachment to be happy.",
    author: "Chanakya",
  },
  { quote: "A man is great by deeds, not by birth.", author: "Chanakya" },
  { quote: "Humbleness is at the root of self control.", author: "Chanakya" },
  {
    quote:
      "Education is the best friend. An educated person is respected everywhere. Education beats the beauty and the youth.",
    author: "Chanakya",
  },
  {
    quote:
      "Test a servant while in the discharge of his duty, a relative difficulty, a friend in adversity, and a wife in misfortune.",
    author: "Chanakya",
  },
  {
    quote:
      "Once you start working on something don’t be afraid of failure and don’t abandon it . People who work sincerely are the happiest.",
    author: "Chanakya",
  },
  {
    quote: "As soon as the fear approaches near, attack and destroy it.",
    author: "Chanakya",
  },
  {
    quote:
      "Never make friends with people who are above or below you in status . Such friendships will never give you any happiness",
    author: "Chanakya",
  },
  {
    quote:
      "Books are as useful to a stupid person as a mirror is useful to a blind person.",
    author: "Chanakya",
  },
  {
    quote:
      "Treat your kid like a darling for the first five years. For the next five years, scold them. By the time they turn sixteen, treat them like a friend. Your grown up children are your best friends.",
    author: "Chanakya",
  },
  {
    quote:
      "The fragrance of flowers spreads only in the directions of the wind. But, the goodness of a person spreads in all direction.",
    author: "Chanakya",
  },
  {
    quote:
      "Drop the idea that attachment and love are one thing. They are enemies. It is attachment that destroys all love.",
    author: "Chanakya",
  },
  {
    quote:
      "The earth is supported by the power of truth, it is the power of truth that makes the sun shine and the winds blow, indeed all things rest upon truth.",
    author: "Chanakya",
  },
  {
    quote:
      "The one who loves all intensely begins perceiving in all living beings a part of himself. He becomes a lover of all, a part and parcel of the Universal Joy. He flows with the stream of happiness, and is enriched by each soul.",
    author: "Yajur Veda",
  },
  {
    quote:
      "The human body is the temple of God. One who kindles the light of awareness within gets true light. The sacred flame of your inner shrine is constantly bright. The experience of unity is the fulfillment of human endeavors. The mysteries of life are revealed.",
    author: "Rig Veda",
  },
  {
    quote:
      "Of everything he is the inmost Self. He is the truth; he is the Self supreme.",
    author: "Chandogya Upanishad",
  },
  {
    quote:
      "Lead us from the unreal to the real. Lead us from darkness to light. Lead us from death to immortality. Shanti, Shanti, Shanti, Om.",
    author: "Brhadaranyaka Upanishad",
  },
  {
    quote:
      "Truth is one but scholars (or different people) perceive it in a different way..",
    author: "Unknown",
  },
  {
    quote: "Mother, Father, Teacher and then God in that order of importance.",
    author: "unknown",
  },
  {
    quote: "Do your duty and do not expect the fruits of the results.",
    author: "Krishna",
  },
  {
    quote:
      "You are born from the one and in the end you will merge into the one.",
    author: "Krishna",
  },
  {
    quote:
      "For yesterday is only a dream, and tomorrow is but a vision. But today, well lived, makes every yesterday a dream of happiness, and every tomorrow a vision of hope.",
    author: "Kalidasa",
  },
];

const quoteBtn = document.querySelector("#quoteBtn");
const quote = document.querySelector("#quote");
const author = document.querySelector("#author");

quoteBtn.addEventListener("click", function () {
  let random = Math.floor(Math.random() * quoteArray.length);
  quote.innerHTML = quoteArray[random].quote;
  author.innerHTML = quoteArray[random].author;
});
