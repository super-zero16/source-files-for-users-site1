const docBody = document.querySelector("body");
const colName = document.querySelector(".colName");
const selectBox = document.querySelector(".myselect");
const shadeBtn = document.querySelector(".shadeBtn");
//const below used only for black option, to pop up the message line
const msgLine = document.querySelector(".msg");

let selected; // to hold value of dropdown menu selection

function random () {
  return Math.floor(Math.random()*255);
}
//the function below is used only for black option
function randomSeeded (n) {
  return Math.floor(Math.random()*n);
}

shadeBtn.addEventListener("click", function(){
    selected = selectBox.value;
    let red; //to hold value of red component
    let green; //to hold value of green component
    let blue; //to hold value of blue component
  
  if (selected=="Red"||selected=="red"){
    red=0;
    green=0;
    blue=0;
    let calculatedCol ="";
    while ((red<=green || red<=blue) ||(green>0.7*red||blue>0.7*red)){
    red = random();
    green = random();
    blue = random();
      if((red<=green || red<=blue) ||(green>0.7*red||blue>0.7*red)){
        continue;
      }
      else {
        calculatedCol = "rgb("+red+","+green+","+blue+")";
        break;
      }
      
    }

    
    docBody.style.backgroundColor=calculatedCol;
    colName.innerHTML=calculatedCol;
  }
  else if (selected=="Green"||selected=="green"){
    red=0;
    green=0;
    blue=0;
    let calculatedCol ="";
    while ((green<=red || green<=blue) ||(red>0.7*green||blue>0.7*green)){
    red = random();
    green = random();
    blue = random();
      if((green<=red || green<=blue) ||(red>0.7*green||blue>0.7*green)){
        continue;
      }
      else {
        calculatedCol = "rgb("+red+","+green+","+blue+")";
        break;
      }
      
    }

    docBody.style.backgroundColor=calculatedCol;
      colName.innerHTML=calculatedCol;
  }
  else if(selected=="Blue"|| selected=="blue"){
    red=0;
    green=0;
    blue=0;
    let calculatedCol ="";
    while ((blue<=red || blue<=green) ||(red>0.7*blue||green>0.7*blue)){
    red = random();
    green = random();
    blue = random();
      if((blue<=red || blue<=green) ||(red>0.7*blue||green>0.7*blue)){
        continue;
      }
      else {
        calculatedCol = "rgb("+red+","+green+","+blue+")";
        break;
      }
      
    }

    docBody.style.backgroundColor=calculatedCol;
      colName.innerHTML=calculatedCol;
  }

  //code below for black or grey option
  else if(selected=="Black"|| selected=="black") {
    red=0;
    green=0;
    blue=0;
    let calculatedCol ="";
    do {
    red = randomSeeded(235);
    green = randomSeeded(235);
    blue = randomSeeded(235);
      if(!(red==green && green==blue)){
        continue;
      }
      else {
        calculatedCol = "rgb("+red+","+green+","+blue+")";
        break;
      }
      
    } while(!(red==green && green==blue))

    docBody.style.backgroundColor=calculatedCol;
      colName.innerHTML=calculatedCol;
      msgLine.style.color="red";
      
  }

});

